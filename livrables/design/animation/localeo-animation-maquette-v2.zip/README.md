
  # Localeo Animation

  This is a code bundle for Localeo Animation. The original project is available at https://www.figma.com/design/KvMa5gaa4PkbpLfwqftqAN/Localeo-Animation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  