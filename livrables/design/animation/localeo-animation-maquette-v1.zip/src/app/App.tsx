import { useState } from "react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import localeoAnimationLogo from "@/imports/localeo_animation.png";
import {
  LayoutDashboard, List, Layers, Gift, Users, CheckSquare,
  Shuffle, FileImage, BarChart2, CreditCard, HelpCircle, Bell,
  ChevronDown, MapPin, AlertTriangle, CheckCircle2,
  ArrowRight, Download, RefreshCw, Send, Edit3,
  TrendingUp, Search, ChevronRight, Check, AlertCircle,
  Calendar, Store, FileText, Plus, X, Ticket, Info,
  ChevronLeft, Trophy, Zap, QrCode, Settings,
  Clock, Package, Activity, ClipboardList, UserCheck,
} from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, BarChart, Bar, Legend,
} from "recharts";

// ── Types ─────────────────────────────────────────────────────────────────
interface Animation {
  id: number;
  name: string;
  commune: string;
  model: string;
  period: string;
  status: string;
  workflowStep: number;
  inscrits: number;
  termines: number;
  validations: number;
  qualifies: number;
  alertes: string[];
  nextAction: string | null;
}

// ── Data ──────────────────────────────────────────────────────────────────
const CHART_DATA = [
  { semaine: "S1", inscrits: 32, validations: 78 },
  { semaine: "S2", inscrits: 58, validations: 134 },
  { semaine: "S3", inscrits: 91, validations: 210 },
  { semaine: "S4", inscrits: 124, validations: 298 },
  { semaine: "S5", inscrits: 163, validations: 412 },
  { semaine: "S6", inscrits: 198, validations: 523 },
  { semaine: "S7", inscrits: 231, validations: 621 },
  { semaine: "S8", inscrits: 247, validations: 634 },
];

const BAR_DATA = [
  { name: "Maison Lenoir", validations: 218 },
  { name: "Atelier Saveurs", validations: 195 },
  { name: "Comptoir Local", validations: 142 },
  { name: "Librairie Centre", validations: 79 },
];

const ANIMATIONS: Animation[] = [
  {
    id: 1,
    name: "Passeport commerçant – Été 2026",
    commune: "Valmont",
    model: "Passeport commerçant",
    period: "15 juin – 31 août 2026",
    status: "en_cours",
    workflowStep: 5,
    inscrits: 247,
    termines: 148,
    validations: 634,
    qualifies: 89,
    alertes: [],
    nextAction: "Surveiller la progression",
  },
  {
    id: 2,
    name: "Passeport gourmand",
    commune: "Valmont",
    model: "Passeport commerçant",
    period: "1 mars – 31 mai 2026",
    status: "tirage_a_lancer",
    workflowStep: 7,
    inscrits: 312,
    termines: 198,
    validations: 801,
    qualifies: 112,
    alertes: ["tirage_non_lance"],
    nextAction: "Lancer le tirage au sort",
  },
  {
    id: 3,
    name: "Animation Noël 2025",
    commune: "Valmont",
    model: "Passeport commerçant",
    period: "1 – 31 déc. 2025",
    status: "archivee",
    workflowStep: 10,
    inscrits: 253,
    termines: 140,
    validations: 499,
    qualifies: 58,
    alertes: [],
    nextAction: null,
  },
  {
    id: 4,
    name: "Rallye vitrines",
    commune: "Valmont",
    model: "Rallye (bientôt)",
    period: "—",
    status: "brouillon",
    workflowStep: 1,
    inscrits: 0,
    termines: 0,
    validations: 0,
    qualifies: 0,
    alertes: ["modele_non_disponible"],
    nextAction: "Modèle non disponible",
  },
];

const PARTICIPANTS = [
  { id: 1, ref: "PART-0247", date: "02/07/2026", validations: 4, qualifie: true, termine: true },
  { id: 2, ref: "PART-0246", date: "02/07/2026", validations: 3, qualifie: false, termine: false },
  { id: 3, ref: "PART-0245", date: "01/07/2026", validations: 4, qualifie: true, termine: true },
  { id: 4, ref: "PART-0244", date: "01/07/2026", validations: 2, qualifie: false, termine: false },
  { id: 5, ref: "PART-0243", date: "30/06/2026", validations: 4, qualifie: true, termine: true },
];

const GAGNANTS = [
  { id: 1, ref: "PART-0247", coffret: "Coffret Découverte Valmont", envoi: "28/05/2026", consomme: "65 %" },
  { id: 2, ref: "PART-0189", coffret: "Coffret Gourmand Valmont", envoi: "28/05/2026", consomme: "20 %" },
  { id: 3, ref: "PART-0102", coffret: "Coffret Bien-être Valmont", envoi: "29/05/2026", consomme: "0 %" },
];

const NAV_ITEMS = [
  { id: "dashboard",    label: "Tableau de bord",  icon: LayoutDashboard },
  { id: "animations",   label: "Animations",        icon: List },
  { id: "models",       label: "Modèles",           icon: Layers },
  { id: "coffrets",     label: "Coffrets à gagner", icon: Gift },
  { id: "participants", label: "Participants",       icon: Users },
  { id: "validations",  label: "Validations",       icon: CheckSquare },
  { id: "tirages",      label: "Tirages et gains",  icon: Shuffle },
  { id: "flyers",       label: "Flyers",            icon: FileImage },
  { id: "bilans",       label: "Bilans",            icon: BarChart2 },
  { id: "abonnement",   label: "Abonnement",        icon: CreditCard },
  { id: "support",      label: "Support",           icon: HelpCircle },
];

const STATUS_CFG: Record<string, { label: string; color: string; bg: string; dot: string }> = {
  brouillon:        { label: "Brouillon",        color: "text-slate-500",  bg: "bg-slate-100",  dot: "bg-slate-400" },
  configuration:    { label: "Configuration",     color: "text-[#0B3D63]",  bg: "bg-[#EFF5FA]",    dot: "bg-[#0B3D63]" },
  prete:            { label: "Prête à publier",   color: "text-indigo-600",bg: "bg-indigo-50",  dot: "bg-indigo-500" },
  publiee:          { label: "Publiée",           color: "text-sky-700",   bg: "bg-sky-50",     dot: "bg-sky-500" },
  en_cours:         { label: "En cours",          color: "text-green-700", bg: "bg-green-50",   dot: "bg-green-500" },
  cloturee:         { label: "Clôturée",          color: "text-amber-700", bg: "bg-amber-50",   dot: "bg-amber-500" },
  tirage_a_lancer:  { label: "Tirage à lancer",   color: "text-[#DF7720]",bg: "bg-[#FFF1E4]",  dot: "bg-[#FFF1E4]0" },
  gains_a_envoyer:  { label: "Gains à envoyer",   color: "text-[#DF7720]",bg: "bg-[#FFF1E4]",  dot: "bg-[#FFF1E4]0" },
  bilan_disponible: { label: "Bilan disponible",  color: "text-teal-700",  bg: "bg-teal-50",    dot: "bg-teal-500" },
  archivee:         { label: "Archivée",          color: "text-gray-400",  bg: "bg-gray-100",   dot: "bg-gray-300" },
  annulee:          { label: "Annulée",           color: "text-red-600",   bg: "bg-red-50",     dot: "bg-red-500" },
};

// ── Utility components ────────────────────────────────────────────────────
function StatusBadge({ status }: { status: string }) {
  const c = STATUS_CFG[status] ?? STATUS_CFG.brouillon;
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium whitespace-nowrap ${c.bg} ${c.color}`}>
      <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${c.dot}`} />
      {c.label}
    </span>
  );
}

function KPICard({
  label, value, sub, icon: Icon, trend, color = "blue",
}: {
  label: string; value: string; sub?: string; icon: React.ElementType;
  trend?: string; color?: "blue" | "green" | "amber" | "purple" | "teal";
}) {
  const colorMap = {
    blue:   "text-[#0B3D63] bg-[#EFF5FA]",
    green:  "text-green-600 bg-green-50",
    amber:  "text-amber-600 bg-amber-50",
    purple: "text-purple-600 bg-purple-50",
    teal:   "text-teal-600 bg-teal-50",
  };
  return (
    <div className="bg-white rounded-lg border border-border p-4 flex flex-col gap-3">
      <div className="flex items-start justify-between">
        <span className="text-xs text-muted-foreground">{label}</span>
        <span className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${colorMap[color]}`}>
          <Icon size={14} />
        </span>
      </div>
      <div>
        <div className="text-2xl font-semibold text-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{value}</div>
        {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
      </div>
      {trend && (
        <div className="flex items-center gap-1 text-xs text-green-600">
          <TrendingUp size={11} />
          {trend}
        </div>
      )}
    </div>
  );
}

function AlertBanner({
  type, message, action, onAction,
}: {
  type: "warning" | "error" | "info"; message: string; action?: string; onAction?: () => void;
}) {
  const cfgs = {
    warning: { wrap: "bg-amber-50 border-amber-200", icon: AlertTriangle, iconCls: "text-amber-500", textCls: "text-amber-800", actCls: "text-amber-700" },
    error:   { wrap: "bg-red-50 border-red-200",     icon: AlertCircle,   iconCls: "text-red-500",   textCls: "text-red-800",   actCls: "text-red-700" },
    info:    { wrap: "bg-[#EFF5FA] border-[#BFD5E8]",   icon: Info,          iconCls: "text-blue-500",  textCls: "text-[#082840]",  actCls: "text-[#0B3D63]" },
  };
  const c = cfgs[type];
  const Icon = c.icon;
  return (
    <div className={`flex items-start gap-3 p-3 rounded-lg border ${c.wrap}`}>
      <Icon size={15} className={`mt-0.5 shrink-0 ${c.iconCls}`} />
      <span className={`text-sm flex-1 ${c.textCls}`}>{message}</span>
      {action && (
        <button onClick={onAction} className={`text-xs font-semibold shrink-0 hover:underline ${c.actCls}`}>
          {action}
        </button>
      )}
    </div>
  );
}

function WorkflowBar({ step, total = 10 }: { step: number; total?: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {Array.from({ length: total }).map((_, i) => (
        <div
          key={i}
          className={`h-1.5 rounded-full transition-all ${
            i < step ? "bg-[#0B3D63]" : i === step - 1 ? "bg-[#4A90E2]" : "bg-gray-200"
          }`}
          style={{ width: 11 }}
        />
      ))}
    </div>
  );
}

// ── Layout ────────────────────────────────────────────────────────────────
function Sidebar({ current, onNav }: { current: string; onNav: (v: string) => void }) {
  return (
    <aside className="w-56 bg-[#082840] flex flex-col h-full shrink-0 overflow-hidden">
      <div className="h-14 flex items-center px-4 border-b border-white/[0.07] shrink-0">
        <div className="flex items-center gap-2.5">
          <ImageWithFallback
            src={localeoAnimationLogo}
            alt="Localeo Animation"
            className="h-9 w-9 object-contain shrink-0"
          />
          <div className="leading-tight">
            <div className="text-white text-sm font-bold tracking-wide">Localeo</div>
            <div className="text-[#F28A2E] text-[10px] font-semibold uppercase tracking-[0.12em]">Animation</div>
          </div>
        </div>
      </div>

      <nav className="flex-1 py-2 overflow-y-auto">
        {NAV_ITEMS.map(({ id, label, icon: Icon }) => {
          const active = current === id || (current === "animation-detail" && id === "animations");
          return (
            <button
              key={id}
              onClick={() => onNav(id)}
              className={`w-full flex items-center gap-3 px-4 py-2 text-sm transition-colors ${
                active
                  ? "bg-white/10 text-white font-medium"
                  : "text-white/50 hover:text-white/80 hover:bg-white/[0.04]"
              }`}
            >
              <Icon size={15} className="shrink-0" />
              {label}
            </button>
          );
        })}
      </nav>

      <div className="border-t border-white/[0.07] p-4 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-[#F28A2E] flex items-center justify-center text-white text-xs font-semibold shrink-0">
            CM
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-white text-xs font-medium truncate">Claire Martin</div>
            <div className="text-white/35 text-[11px] truncate">OT de Valmont</div>
          </div>
          <Settings size={13} className="text-white/30 hover:text-white/70 cursor-pointer shrink-0 transition-colors" />
        </div>
      </div>
    </aside>
  );
}

function TopBar({ onNav }: { onNav: (v: string) => void }) {
  const [notifOpen, setNotifOpen] = useState(false);
  return (
    <header className="h-14 bg-white border-b border-border flex items-center px-5 gap-3 shrink-0 relative z-20">
      <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-border hover:bg-muted/50 transition-colors">
        <MapPin size={13} className="text-[#0B3D63] shrink-0" />
        <span className="text-sm font-medium text-foreground">Ville de Valmont</span>
        <ChevronDown size={13} className="text-muted-foreground" />
      </button>

      <div className="flex-1" />

      <button
        onClick={() => onNav("abonnement")}
        className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-green-50 border border-green-200 hover:bg-green-100 transition-colors"
      >
        <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
        <span className="text-xs font-medium text-green-700">Actif</span>
      </button>

      <button className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-muted/50 transition-colors">
        <HelpCircle size={17} className="text-muted-foreground" />
      </button>

      <div className="relative">
        <button
          onClick={() => setNotifOpen(!notifOpen)}
          className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-muted/50 transition-colors relative"
        >
          <Bell size={17} className="text-muted-foreground" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-[#FFF1E4]0 rounded-full" />
        </button>
        {notifOpen && (
          <div className="absolute right-0 top-full mt-1 w-80 bg-white rounded-xl border border-border shadow-xl z-50">
            <div className="px-4 py-3 border-b border-border flex items-center justify-between">
              <span className="text-sm font-semibold">Notifications</span>
              <button onClick={() => setNotifOpen(false)}>
                <X size={14} className="text-muted-foreground" />
              </button>
            </div>
            <div className="divide-y divide-border">
              <div className="px-4 py-3 hover:bg-muted/20 cursor-pointer">
                <div className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#FFF1E4]0 mt-1.5 shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-foreground">Tirage à lancer</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Passeport gourmand — 112 participants éligibles</p>
                    <p className="text-[11px] text-muted-foreground mt-1">Il y a 2 heures</p>
                  </div>
                </div>
              </div>
              <div className="px-4 py-3 hover:bg-muted/20 cursor-pointer">
                <div className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-foreground">Faible participation</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Passeport Été 2026 — 12 validations cette semaine</p>
                    <p className="text-[11px] text-muted-foreground mt-1">Il y a 1 jour</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}

// ── Views ─────────────────────────────────────────────────────────────────
function DashboardView({ onOpen }: { onOpen: (id: number) => void }) {
  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-foreground">Tableau de bord</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Ville de Valmont · Période : janvier – juillet 2026</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-white text-xs font-medium text-foreground hover:bg-muted/30 transition-colors">
            <Calendar size={13} /> Période <ChevronDown size={12} className="text-muted-foreground" />
          </button>
          <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-white text-xs font-medium text-foreground hover:bg-muted/30 transition-colors">
            Statut <ChevronDown size={12} className="text-muted-foreground" />
          </button>
        </div>
      </div>

      <AlertBanner
        type="warning"
        message="Passeport gourmand — Tirage non lancé. Population éligible figée : 112 participants."
        action="Lancer le tirage →"
      />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KPICard label="Animations publiées" value="4" icon={List} color="blue" sub="dont 1 en cours" />
        <KPICard label="Inscrits total" value="812" icon={Users} color="green" trend="+247 sur Été 2026" />
        <KPICard label="Taux de complétion" value="60 %" icon={TrendingUp} color="teal" sub="486 / 812 participants" />
        <KPICard label="Participants qualifiés" value="214" icon={Trophy} color="purple" sub="26 % des inscrits" />
        <KPICard label="Validations totales" value="1 934" icon={CheckSquare} color="blue" sub="Chez 4 commerçants" />
        <KPICard label="Coffrets envoyés" value="45" icon={Gift} color="amber" />
        <KPICard label="Consommation coffrets" value="38 %" icon={Zap} color="teal" sub="17 / 45 consommés" />
        <KPICard label="Animations terminées" value="3" icon={CheckCircle2} color="green" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white rounded-lg border border-border p-4">
          <p className="text-sm font-semibold text-foreground mb-4">Progression – Passeport commerçant Été 2026</p>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={CHART_DATA} margin={{ top: 4, right: 12, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e4e7ed" />
              <XAxis dataKey="semaine" tick={{ fontSize: 11, fill: "#94a3b8" }} />
              <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #e4e7ed", boxShadow: "0 2px 8px rgba(0,0,0,.08)" }} />
              <Legend iconType="circle" iconSize={7} wrapperStyle={{ fontSize: 11, paddingTop: 8 }} />
              <Line type="monotone" dataKey="inscrits" stroke="#0B3D63" strokeWidth={2} dot={false} name="Inscrits" />
              <Line type="monotone" dataKey="validations" stroke="#28A85F" strokeWidth={2} dot={false} name="Validations" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-lg border border-border p-4">
          <p className="text-sm font-semibold text-foreground mb-4">Top commerçants</p>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={BAR_DATA} layout="vertical" margin={{ top: 0, right: 8, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e4e7ed" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 10, fill: "#94a3b8" }} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: "#64748b" }} width={95} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #e4e7ed" }} />
              <Bar dataKey="validations" fill="#0B3D63" radius={[0, 3, 3, 0]} name="Validations" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-border overflow-hidden">
        <div className="px-4 py-3 border-b border-border flex items-center justify-between">
          <p className="text-sm font-semibold text-foreground">Animations nécessitant une action</p>
        </div>
        <div className="divide-y divide-border">
          {ANIMATIONS.filter(a => a.nextAction && a.status !== "archivee").map(a => (
            <div key={a.id} className="flex items-center gap-4 px-4 py-3 hover:bg-muted/20 transition-colors">
              <StatusBadge status={a.status} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">{a.name}</p>
                <p className="text-xs text-muted-foreground">{a.period}</p>
              </div>
              <WorkflowBar step={a.workflowStep} />
              <span className={`text-xs px-2 py-1 rounded font-medium shrink-0 ${
                a.alertes.length ? "bg-[#FFF1E4] text-[#DF7720]" : "bg-muted text-muted-foreground"
              }`}>
                {a.nextAction}
              </span>
              <button
                onClick={() => onOpen(a.id)}
                className="flex items-center gap-1 text-xs text-[#0B3D63] hover:text-[#0B3D63] font-medium shrink-0 transition-colors"
              >
                Ouvrir <ChevronRight size={13} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AnimationsView({ onOpen, onCreate }: { onOpen: (id: number) => void; onCreate: () => void }) {
  const [search, setSearch] = useState("");
  const filtered = ANIMATIONS.filter(a =>
    a.name.toLowerCase().includes(search.toLowerCase()) ||
    a.commune.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-foreground">Animations</h1>
          <p className="text-xs text-muted-foreground mt-0.5">{ANIMATIONS.length} animations · Ville de Valmont</p>
        </div>
        <button onClick={onCreate} className="flex items-center gap-2 px-4 py-2 bg-[#0B3D63] text-white rounded-lg text-sm font-medium hover:bg-[#0D456D] transition-colors">
          <Plus size={15} /> Nouvelle animation
        </button>
      </div>

      <div className="flex items-center gap-3 bg-white rounded-lg border border-border p-2.5">
        <div className="flex items-center gap-2 flex-1 max-w-xs px-1">
          <Search size={14} className="text-muted-foreground shrink-0" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Rechercher..."
            className="text-sm bg-transparent outline-none text-foreground placeholder:text-muted-foreground flex-1"
          />
        </div>
        <div className="h-4 w-px bg-border" />
        {["Statut", "Modèle", "Période", "Alertes"].map(f => (
          <button key={f} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-muted/40 transition-colors">
            <ChevronDown size={12} /> {f}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-lg border border-border overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/20">
              {["Animation", "Modèle", "Période", "Statut", "Workflow", "Inscrits", "Validations", "Action suivante", ""].map(h => (
                <th key={h} className={`px-4 py-2.5 text-left text-[11px] font-semibold text-muted-foreground uppercase tracking-wide ${
                  h === "Inscrits" || h === "Validations" ? "text-right" : ""
                }`}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.map(a => (
              <tr
                key={a.id}
                onClick={() => onOpen(a.id)}
                className="hover:bg-muted/20 transition-colors cursor-pointer"
              >
                <td className="px-4 py-3">
                  <p className="font-medium text-foreground">{a.name}</p>
                  <p className="text-[11px] text-muted-foreground">{a.commune}</p>
                </td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{a.model}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{a.period}</td>
                <td className="px-4 py-3"><StatusBadge status={a.status} /></td>
                <td className="px-4 py-3"><WorkflowBar step={a.workflowStep} /></td>
                <td className="px-4 py-3 text-right text-sm" style={{ fontFamily: "'Geist Mono', monospace" }}>{a.inscrits}</td>
                <td className="px-4 py-3 text-right text-sm" style={{ fontFamily: "'Geist Mono', monospace" }}>{a.validations}</td>
                <td className="px-4 py-3">
                  {a.nextAction ? (
                    <span className={`text-xs ${a.alertes.length ? "text-[#DF7720] font-medium" : "text-muted-foreground"}`}>
                      {a.nextAction}
                    </span>
                  ) : <span className="text-xs text-muted-foreground">—</span>}
                </td>
                <td className="px-4 py-3">
                  <ChevronRight size={15} className="text-muted-foreground" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Animation detail ──────────────────────────────────────────────────────
function AnimationDetailView({ id, onBack }: { id: number; onBack: () => void }) {
  const [tab, setTab] = useState("workflow");
  const anim = ANIMATIONS.find(a => a.id === id) ?? ANIMATIONS[0];
  const TABS = [
    { id: "workflow",      label: "Workflow" },
    { id: "live",          label: "Live" },
    { id: "configuration", label: "Configuration" },
    { id: "participants",  label: "Participants" },
    { id: "validations",   label: "Validations" },
    { id: "tirage",        label: "Tirage" },
    { id: "gains",         label: "Gains & coffrets" },
    { id: "flyer",         label: "Flyer" },
    { id: "bilan",         label: "Bilan" },
    { id: "audit",         label: "Audit" },
  ];

  return (
    <div className="flex flex-col h-full min-h-0">
      <div className="bg-white border-b border-border px-6 py-4 shrink-0">
        <button
          onClick={onBack}
          className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground mb-3 transition-colors"
        >
          <ChevronLeft size={13} /> Animations
        </button>
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-base font-semibold text-foreground">{anim.name}</h1>
              <StatusBadge status={anim.status} />
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">{anim.commune} · {anim.period}</p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {anim.status === "en_cours" && (
              <button className="px-3 py-1.5 text-xs border border-amber-300 text-amber-700 rounded-lg hover:bg-amber-50 transition-colors font-medium">
                Clôturer
              </button>
            )}
            {anim.status === "tirage_a_lancer" && (
              <button
                onClick={() => setTab("tirage")}
                className="px-3 py-1.5 text-xs bg-[#F28A2E] text-white rounded-lg hover:bg-[#DF7720] transition-colors font-medium"
              >
                Lancer le tirage
              </button>
            )}
            <button className="w-7 h-7 flex items-center justify-center border border-border rounded-lg hover:bg-muted/30 transition-colors">
              <Edit3 size={13} className="text-muted-foreground" />
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white border-b border-border px-6 shrink-0 overflow-x-auto">
        <div className="flex gap-0">
          {TABS.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`px-3 py-3 text-xs font-medium border-b-2 whitespace-nowrap transition-colors ${
                tab === t.id
                  ? "border-[#0B3D63] text-[#0B3D63]"
                  : "border-transparent text-muted-foreground hover:text-foreground hover:border-border"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {tab === "workflow"     && <WorkflowTab anim={anim} onTabChange={setTab} />}
        {tab === "live"         && <LiveTab anim={anim} />}
        {tab === "tirage"       && <TirageTab anim={anim} />}
        {tab === "participants" && <ParticipantsTab />}
        {tab === "flyer"        && <FlyerTab anim={anim} />}
        {tab === "bilan"        && <BilanTab anim={anim} />}
        {tab === "configuration" && <ConfigurationTab anim={anim} />}
        {tab === "validations"   && <ValidationsAnimTab anim={anim} />}
        {tab === "gains"         && <GainsAnimTab anim={anim} />}
        {tab === "audit"         && <AuditTab anim={anim} />}
      </div>
    </div>
  );
}

function WorkflowTab({ anim, onTabChange }: { anim: Animation; onTabChange: (t: string) => void }) {
  const steps = [
    { n: 1, label: "Brouillon",        desc: "Animation créée, configuration non démarrée" },
    { n: 2, label: "Configuration",    desc: "Paramètres en cours de saisie" },
    { n: 3, label: "Prête à publier",  desc: "Configuration complète, prête à être publiée" },
    { n: 4, label: "Publiée",          desc: "QR d'inscription actif, inscription ouverte" },
    { n: 5, label: "En cours",         desc: "Participants en train de valider leurs étapes" },
    { n: 6, label: "Clôturée",         desc: "Fin des validations, aucune nouvelle inscription" },
    { n: 7, label: "Tirage à lancer",  desc: "Population éligible figée, tirage possible" },
    { n: 8, label: "Gains à envoyer",  desc: "Tirage effectué, envoi des coffrets en attente" },
    { n: 9, label: "Bilan disponible", desc: "Résultats complets accessibles et exportables" },
    { n: 10, label: "Archivée",        desc: "Animation terminée et archivée" },
  ];

  return (
    <div className="p-6 space-y-4">
      {anim.alertes.includes("tirage_non_lance") && (
        <AlertBanner
          type="warning"
          message="Tirage non lancé. Population éligible figée à 112 participants. Cette étape est requise avant l'envoi des gains."
          action="Aller au tirage →"
          onAction={() => onTabChange("tirage")}
        />
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white rounded-lg border border-border p-5">
          <p className="text-sm font-semibold text-foreground mb-5">Cycle de vie</p>
          <div className="space-y-0">
            {steps.map((s, i) => {
              const done    = s.n < anim.workflowStep;
              const current = s.n === anim.workflowStep;
              const pending = s.n > anim.workflowStep;
              return (
                <div key={s.n} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 border-2 transition-all ${
                      done    ? "bg-[#0B3D63] border-[#0B3D63]" :
                      current ? "bg-white border-[#0B3D63]" :
                               "bg-white border-gray-200"
                    }`}>
                      {done    ? <Check size={12} className="text-white" /> :
                       current ? <span className="w-2 h-2 bg-[#0B3D63] rounded-full" /> :
                                 <span className="w-1.5 h-1.5 bg-gray-300 rounded-full" />}
                    </div>
                    {i < steps.length - 1 && (
                      <div className={`w-px flex-1 min-h-[28px] ${done ? "bg-[#4A90E2]" : "bg-gray-200"}`} />
                    )}
                  </div>
                  <div className="pb-5 flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`text-sm font-medium ${current ? "text-[#0B3D63]" : pending ? "text-muted-foreground" : "text-foreground"}`}>
                        {s.label}
                      </span>
                      {current && (
                        <span className="text-[10px] bg-[#EFF5FA] text-[#0B3D63] px-1.5 py-0.5 rounded-full font-semibold uppercase tracking-wide">
                          Étape actuelle
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">{s.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="space-y-3">
          {anim.nextAction && (
            <div className="bg-[#EFF5FA] border border-[#BFD5E8] rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Zap size={14} className="text-[#0B3D63]" />
                <p className="text-xs font-semibold text-[#082840] uppercase tracking-wide">Action recommandée</p>
              </div>
              <p className="text-sm text-[#082840] mb-3">{anim.nextAction}</p>
              <button className="flex items-center gap-1 text-xs font-semibold text-[#0B3D63] hover:text-[#082840] transition-colors">
                Agir maintenant <ArrowRight size={12} />
              </button>
            </div>
          )}

          <div className="bg-white rounded-lg border border-border p-4 space-y-3">
            <p className="text-xs font-semibold text-foreground">Résumé</p>
            <div className="space-y-2">
              {[
                { label: "Inscrits",    value: String(anim.inscrits) },
                { label: "Terminés",    value: String(anim.termines) },
                { label: "Qualifiés",   value: String(anim.qualifies) },
                { label: "Validations", value: String(anim.validations) },
              ].map(({ label, value }) => (
                <div key={label} className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">{label}</span>
                  <span className="text-sm font-semibold text-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{value}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg border border-border p-4">
            <p className="text-xs font-semibold text-foreground mb-2">Actions disponibles</p>
            <div className="space-y-1.5">
              {anim.status === "en_cours" && (
                <button className="w-full text-left text-xs px-3 py-2 rounded-lg border border-amber-200 text-amber-700 hover:bg-amber-50 transition-colors font-medium">
                  Clôturer l'animation
                </button>
              )}
              {anim.status === "tirage_a_lancer" && (
                <button
                  onClick={() => onTabChange("tirage")}
                  className="w-full text-left text-xs px-3 py-2 rounded-lg bg-[#F28A2E] text-white hover:bg-[#DF7720] transition-colors font-medium"
                >
                  Lancer le tirage →
                </button>
              )}
              <button className="w-full text-left text-xs px-3 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground hover:bg-muted/30 transition-colors">
                Voir le bilan
              </button>
              <button className="w-full text-left text-xs px-3 py-2 rounded-lg border border-border text-muted-foreground hover:text-foreground hover:bg-muted/30 transition-colors">
                Télécharger le flyer
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LiveTab({ anim }: { anim: Animation }) {
  const pct = anim.inscrits > 0 ? Math.round((anim.termines / anim.inscrits) * 100) : 0;
  return (
    <div className="p-6 space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KPICard label="Inscrits" value={String(anim.inscrits)} icon={Users} color="blue" />
        <KPICard label="Participants terminés" value={String(anim.termines)} icon={CheckCircle2} color="green" />
        <KPICard label="Taux de complétion" value={`${pct} %`} icon={TrendingUp} color="teal" />
        <KPICard label="Qualifiés" value={String(anim.qualifies)} icon={Trophy} color="purple" />
      </div>

      <div className="bg-white rounded-lg border border-border p-4">
        <div className="flex items-center justify-between mb-2.5">
          <p className="text-sm font-semibold text-foreground">Progression globale</p>
          <span className="text-xs text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>
            {anim.termines} / {anim.inscrits}
          </span>
        </div>
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div className="h-full bg-[#0B3D63] rounded-full transition-all" style={{ width: `${pct}%` }} />
        </div>
        <div className="flex justify-between mt-1.5 text-[11px] text-muted-foreground">
          <span>0</span>
          <span>{pct} % terminés</span>
          <span>{anim.inscrits}</span>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-border overflow-hidden">
        <div className="px-4 py-3 border-b border-border">
          <p className="text-sm font-semibold text-foreground">Validations récentes</p>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/20">
              {["Date", "Commerçant", "Participant (ref)", "Résultat"].map(h => (
                <th key={h} className="text-left px-4 py-2 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {[
              { date: "02/07/2026 14h23", merchant: "Maison Lenoir",         ref: "PART-0247", ok: true },
              { date: "02/07/2026 13h51", merchant: "Atelier des Saveurs",   ref: "PART-0246", ok: true },
              { date: "02/07/2026 12h08", merchant: "Le Comptoir Local",     ref: "PART-0245", ok: true },
              { date: "01/07/2026 17h34", merchant: "Librairie du Centre",   ref: "PART-0244", ok: false },
              { date: "01/07/2026 16h12", merchant: "Maison Lenoir",         ref: "PART-0243", ok: true },
            ].map((v, i) => (
              <tr key={i} className="hover:bg-muted/20 transition-colors">
                <td className="px-4 py-2 text-[11px] text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{v.date}</td>
                <td className="px-4 py-2 text-sm">{v.merchant}</td>
                <td className="px-4 py-2 text-[11px] text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{v.ref}</td>
                <td className="px-4 py-2">
                  {v.ok
                    ? <span className="text-[11px] bg-green-50 text-green-700 px-2 py-0.5 rounded font-medium">Validé</span>
                    : <span className="text-[11px] bg-red-50 text-red-700 px-2 py-0.5 rounded font-medium">Anomalie</span>
                  }
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function TirageTab({ anim }: { anim: Animation }) {
  const [state, setState] = useState<"idle" | "confirm" | "done">("idle");
  const canDraw = anim.status === "tirage_a_lancer" || anim.status === "cloturee" || anim.status === "gains_a_envoyer";

  return (
    <div className="p-6 space-y-4">
      <div className="grid grid-cols-3 gap-3">
        <KPICard label="Participants éligibles" value={String(anim.qualifies)} icon={Users} color="blue" sub="Figée à la clôture" />
        <KPICard label="Coffrets à gagner" value="3" icon={Gift} color="amber" />
        <KPICard label="Statut tirage" value={state === "done" ? "Effectué" : "En attente"} icon={Shuffle} color={state === "done" ? "green" : "teal"} />
      </div>

      <div className="bg-white rounded-lg border border-border p-4">
        <p className="text-sm font-semibold text-foreground mb-3">Coffrets à gagner</p>
        <div className="space-y-2">
          {["Coffret Découverte Valmont", "Coffret Gourmand Valmont", "Coffret Bien-être Valmont"].map(c => (
            <div key={c} className="flex items-center gap-3 px-3 py-2 rounded-lg bg-muted/30 border border-border">
              <Gift size={13} className="text-amber-600 shrink-0" />
              <span className="text-sm text-foreground flex-1">{c}</span>
              <span className="text-[11px] bg-green-50 text-green-700 px-2 py-0.5 rounded font-medium border border-green-200">Actif · Valmont</span>
            </div>
          ))}
        </div>
      </div>

      {!canDraw && (
        <AlertBanner
          type="info"
          message="Le tirage ne peut être lancé que lorsque l'animation est clôturée et la population éligible est figée."
        />
      )}

      {canDraw && state === "idle" && (
        <div className="bg-white rounded-lg border border-border p-8 text-center">
          <div className="w-12 h-12 rounded-full bg-[#FFF1E4] flex items-center justify-center mx-auto mb-3">
            <Shuffle size={22} className="text-[#F28A2E]" />
          </div>
          <p className="text-sm font-semibold text-foreground mb-1">Prêt à lancer le tirage</p>
          <p className="text-xs text-muted-foreground mb-5">
            {anim.qualifies} participants éligibles · 3 coffrets disponibles
          </p>
          <button
            onClick={() => setState("confirm")}
            className="px-6 py-2 bg-[#F28A2E] text-white rounded-lg text-sm font-medium hover:bg-[#DF7720] transition-colors"
          >
            Lancer le tirage au sort
          </button>
        </div>
      )}

      {state === "confirm" && (
        <div className="bg-[#FFF1E4] border border-[#FDDBB0] rounded-lg p-6 text-center">
          <AlertTriangle size={22} className="mx-auto mb-3 text-[#F28A2E]" />
          <p className="text-sm font-semibold text-orange-900 mb-1">Confirmer le lancement du tirage ?</p>
          <p className="text-xs text-[#DF7720] mb-5">
            Action irréversible. {anim.qualifies} participants éligibles seront soumis au tirage.
          </p>
          <div className="flex justify-center gap-3">
            <button
              onClick={() => setState("idle")}
              className="px-4 py-2 border border-border rounded-lg text-sm bg-white hover:bg-muted/30 transition-colors"
            >
              Annuler
            </button>
            <button
              onClick={() => setState("done")}
              className="px-4 py-2 bg-[#F28A2E] text-white rounded-lg text-sm font-medium hover:bg-[#DF7720] transition-colors"
            >
              Confirmer le tirage
            </button>
          </div>
        </div>
      )}

      {state === "done" && (
        <div className="bg-white rounded-lg border border-border overflow-hidden">
          <div className="px-4 py-3 border-b border-border flex items-center gap-2">
            <CheckCircle2 size={15} className="text-green-600" />
            <p className="text-sm font-semibold text-foreground">Résultats du tirage</p>
            <span className="ml-auto text-xs text-muted-foreground">02/07/2026 · 15h42</span>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/20">
                {["Participant", "Coffret attribué", "Statut envoi", ""].map(h => (
                  <th key={h} className="text-left px-4 py-2 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {GAGNANTS.map(g => (
                <tr key={g.id} className="hover:bg-muted/20 transition-colors">
                  <td className="px-4 py-2.5 text-xs text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{g.ref}</td>
                  <td className="px-4 py-2.5 text-sm">{g.coffret}</td>
                  <td className="px-4 py-2.5">
                    <span className="text-[11px] bg-green-50 text-green-700 px-2 py-0.5 rounded font-medium">Envoyé</span>
                  </td>
                  <td className="px-4 py-2.5 text-right">
                    <button className="text-xs text-[#0B3D63] hover:underline">Voir coffret</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function ParticipantsTab() {
  return (
    <div className="p-6 space-y-4">
      <AlertBanner
        type="info"
        message="Données personnelles masquées. Seules les références anonymisées sont affichées dans les vues agrégées."
      />
      <div className="bg-white rounded-lg border border-border overflow-hidden">
        <div className="px-4 py-2.5 border-b border-border flex items-center gap-3">
          <Search size={13} className="text-muted-foreground shrink-0" />
          <input
            className="text-sm bg-transparent outline-none flex-1 placeholder:text-muted-foreground"
            placeholder="Filtrer les participants..."
          />
          <button className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-muted/40 transition-colors">
            <ChevronDown size={12} /> Qualifiés
          </button>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/20">
              {["Référence", "Date inscription", "Validations", "Terminé", "Qualifié"].map(h => (
                <th key={h} className={`px-4 py-2 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide ${
                  h === "Validations" ? "text-right" : "text-left"
                }`}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {PARTICIPANTS.map(p => (
              <tr key={p.id} className="hover:bg-muted/20 transition-colors">
                <td className="px-4 py-2.5 text-xs text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{p.ref}</td>
                <td className="px-4 py-2.5 text-xs text-muted-foreground">{p.date}</td>
                <td className="px-4 py-2.5 text-right text-sm font-semibold" style={{ fontFamily: "'Geist Mono', monospace" }}>{p.validations}</td>
                <td className="px-4 py-2.5">
                  {p.termine
                    ? <Check size={13} className="text-green-600" />
                    : <span className="text-xs text-muted-foreground">En cours</span>
                  }
                </td>
                <td className="px-4 py-2.5">
                  {p.qualifie
                    ? <span className="text-[11px] bg-purple-50 text-purple-700 px-2 py-0.5 rounded font-medium">Qualifié</span>
                    : <span className="text-xs text-muted-foreground">—</span>
                  }
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function FlyerTab({ anim }: { anim: Animation }) {
  return (
    <div className="p-6">
      <div className="max-w-lg space-y-4">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 text-xs bg-green-50 text-green-700 border border-green-200 px-2.5 py-1 rounded-full font-medium">
            <CheckCircle2 size={12} /> À jour
          </span>
          <span className="text-xs text-muted-foreground">Généré le 14 juin 2026</span>
        </div>

        <div className="bg-white border-2 border-border rounded-xl overflow-hidden shadow-sm">
          <div className="bg-[#0B3D63] px-6 py-5 text-white text-center">
            <p className="text-[10px] font-semibold uppercase tracking-widest opacity-60 mb-1">Ville de Valmont</p>
            <h2 className="text-lg font-bold leading-snug mb-1">{anim.name}</h2>
            <p className="text-sm opacity-75">{anim.period}</p>
          </div>
          <div className="p-5 flex gap-5 items-start">
            <div className="flex-1">
              <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                Participez au Passeport commerçant ! Visitez les commerçants participants, faites valider votre passeport et tentez de gagner un coffret Localeo.
              </p>
              <div className="space-y-1.5">
                {[
                  ["Organisateur", "Office de tourisme de Valmont"],
                  ["Durée", anim.period],
                  ["Inscription", "localeo.fr/valmont/ete2026"],
                ].map(([k, v]) => (
                  <div key={k} className="flex gap-2 text-xs">
                    <span className="font-semibold text-foreground shrink-0">{k} :</span>
                    <span className="text-muted-foreground">{v}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="w-20 h-20 bg-muted rounded-lg flex flex-col items-center justify-center border border-border shrink-0">
              <QrCode size={28} className="text-muted-foreground" />
              <p className="text-[9px] text-muted-foreground mt-1 text-center leading-tight">QR<br />inscription</p>
            </div>
          </div>
          <div className="border-t border-border px-5 py-2.5 bg-muted/20 flex items-center justify-between">
            <span className="text-[10px] text-muted-foreground">Charte officielle Localeo</span>
            <span className="text-[10px] text-[#0B3D63] font-semibold">localeo.fr</span>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button className="flex items-center gap-2 px-4 py-2 bg-[#0B3D63] text-white rounded-lg text-sm font-medium hover:bg-[#0D456D] transition-colors">
            <Download size={14} /> Télécharger PDF
          </button>
          <button className="flex items-center gap-2 px-4 py-2 border border-border bg-white rounded-lg text-sm hover:bg-muted/30 transition-colors text-muted-foreground hover:text-foreground">
            <RefreshCw size={14} /> Régénérer
          </button>
        </div>
      </div>
    </div>
  );
}

function BilanTab({ anim }: { anim: Animation }) {
  const pct = anim.inscrits > 0 ? Math.round((anim.termines / anim.inscrits) * 100) : 0;
  return (
    <div className="p-6 space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KPICard label="Inscrits" value={String(anim.inscrits)} icon={Users} color="blue" />
        <KPICard label="Terminés" value={String(anim.termines)} icon={CheckCircle2} color="green" sub={`${pct} % complétion`} />
        <KPICard label="Qualifiés" value={String(anim.qualifies)} icon={Trophy} color="purple" />
        <KPICard label="Validations" value={String(anim.validations)} icon={CheckSquare} color="teal" />
      </div>

      <div className="bg-white rounded-lg border border-border overflow-hidden">
        <div className="px-4 py-3 border-b border-border">
          <p className="text-sm font-semibold text-foreground">Résultats par commerçant</p>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/20">
              {["Commerçant", "Validations", "Part du total"].map(h => (
                <th key={h} className={`px-4 py-2 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide ${
                  h !== "Commerçant" ? "text-right" : "text-left"
                }`}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {BAR_DATA.map(b => (
              <tr key={b.name} className="hover:bg-muted/20 transition-colors">
                <td className="px-4 py-2.5 flex items-center gap-2">
                  <Store size={13} className="text-muted-foreground shrink-0" />
                  {b.name}
                </td>
                <td className="px-4 py-2.5 text-right font-semibold" style={{ fontFamily: "'Geist Mono', monospace" }}>{b.validations}</td>
                <td className="px-4 py-2.5 text-right text-muted-foreground text-xs">
                  {Math.round((b.validations / anim.validations) * 100)} %
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <button className="flex items-center gap-2 px-4 py-2 border border-border bg-white rounded-lg text-sm hover:bg-muted/30 transition-colors text-muted-foreground hover:text-foreground">
        <Download size={14} /> Exporter en CSV
      </button>
    </div>
  );
}

// ── Secondary views ───────────────────────────────────────────────────────
function ModelsView({ onNav, onCreate }: { onNav: (v: string) => void; onCreate: () => void }) {
  const models = [
    {
      id: "passeport",
      name: "Passeport commerçant",
      available: true,
      desc: "Les participants collectent des validations en visitant les commerçants participants. Les inscrits ayant atteint le seuil sont éligibles au tirage au sort.",
      prereqs: ["Commune habilitée", "Commerçants participants définis", "Coffrets Localeo actifs sur la commune", "Dates définies", "Règles de qualification configurées"],
    },
    { id: "rallye",  name: "Rallye vitrines",   available: false, desc: "Rallye photo ou découverte autour des vitrines de commerçants. En cours de développement." },
    { id: "chasse",  name: "Chasse au trésor",  available: false, desc: "Jeu de piste géolocalisé autour des commerces locaux. En cours de développement." },
    { id: "quiz",    name: "Quiz commerçants",  available: false, desc: "Questions sur les commerçants locaux pour gagner des points. En cours de développement." },
  ];

  return (
    <div className="p-6 space-y-4">
      <div>
        <h1 className="text-base font-semibold text-foreground">Catalogue des modèles</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Choisissez le type d'animation à créer</p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {models.map(m => (
          <div key={m.id} className={`bg-white rounded-xl border p-5 transition-all ${m.available ? "border-border" : "border-border opacity-55"}`}>
            <div className="flex items-start gap-3 mb-3">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${m.available ? "bg-[#EFF5FA]" : "bg-muted"}`}>
                <Ticket size={17} className={m.available ? "text-[#0B3D63]" : "text-muted-foreground"} />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground">{m.name}</h3>
                {!m.available && (
                  <span className="inline-block text-[10px] bg-muted text-muted-foreground px-1.5 py-0.5 rounded mt-0.5 font-medium uppercase tracking-wide">
                    Bientôt disponible
                  </span>
                )}
              </div>
            </div>
            <p className="text-xs text-muted-foreground mb-4 leading-relaxed">{m.desc}</p>
            {m.prereqs && m.prereqs.length > 0 && (
              <div className="mb-4">
                <p className="text-[11px] font-semibold text-foreground uppercase tracking-wide mb-2">Prérequis</p>
                <ul className="space-y-1">
                  {m.prereqs.map(p => (
                    <li key={p} className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Check size={11} className="text-green-600 shrink-0" /> {p}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {m.available ? (
              <button
                onClick={onCreate}
                className="w-full py-2 bg-[#0B3D63] text-white rounded-lg text-sm font-medium hover:bg-[#0D456D] transition-colors"
              >
                Créer une animation
              </button>
            ) : (
              <button disabled className="w-full py-2 bg-muted text-muted-foreground rounded-lg text-sm font-medium cursor-not-allowed">
                Non disponible
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function AbonnementView() {
  return (
    <div className="p-6 space-y-4 max-w-xl">
      <div>
        <h1 className="text-base font-semibold text-foreground">Abonnement</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Accès et droits sur la plateforme Localeo</p>
      </div>

      <div className="bg-white rounded-xl border border-border p-5">
        <div className="flex items-start justify-between mb-5">
          <div>
            <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-semibold mb-1">Formule</p>
            <h2 className="text-base font-semibold text-foreground">Partenaire Essentiel</h2>
          </div>
          <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-green-50 border border-green-200 text-xs font-semibold text-green-700">
            <span className="w-1.5 h-1.5 bg-green-500 rounded-full" />
            Actif
          </span>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {[
            ["Commune couverte", "Ville de Valmont", true],
            ["Renouvellement", "31 décembre 2026", false],
            ["Facturation", "Annuelle via Stripe", false],
            ["Partenaire", "OT de Valmont", false],
          ].map(([k, v, hasIcon]) => (
            <div key={String(k)}>
              <p className="text-[11px] text-muted-foreground mb-0.5">{k}</p>
              <p className="text-sm font-medium text-foreground flex items-center gap-1">
                {hasIcon && <MapPin size={12} className="text-[#0B3D63]" />} {v}
              </p>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-border p-5">
        <p className="text-sm font-semibold text-foreground mb-3">Droits inclus</p>
        <div className="space-y-2">
          {[
            [true,  "Créer des animations (Passeport commerçant)"],
            [true,  "Gérer les participants et les validations"],
            [true,  "Lancer le tirage au sort"],
            [true,  "Envoyer les coffrets gagnants"],
            [true,  "Exporter les bilans CSV"],
            [false, "Animations multi-communes"],
            [false, "Administration globale des tenants"],
            [false, "Tous les modèles (Rallye, Quiz, Chasse...)"],
          ].map(([ok, label]) => (
            <div key={String(label)} className="flex items-center gap-2.5">
              {ok
                ? <Check size={13} className="text-green-600 shrink-0" />
                : <X size={13} className="text-red-400 shrink-0" />}
              <span className={`text-sm ${ok ? "text-foreground" : "text-muted-foreground"}`}>{label}</span>
            </div>
          ))}
        </div>
      </div>

      <p className="text-xs text-[#0B3D63] hover:underline cursor-pointer font-medium">
        Contacter Localeo pour modifier votre abonnement →
      </p>
    </div>
  );
}

function SupportView() {
  return (
    <div className="p-6 space-y-4 max-w-md">
      <div>
        <h1 className="text-base font-semibold text-foreground">Support</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Aide et contact Localeo</p>
      </div>
      <div className="space-y-2.5">
        {[
          { icon: FileText, title: "Documentation", desc: "Guides et tutoriels pour chaque fonctionnalité" },
          { icon: HelpCircle, title: "FAQ", desc: "Réponses aux questions fréquentes" },
          { icon: Send, title: "Contacter le support", desc: "Envoyer un message à l'équipe Localeo" },
        ].map(item => (
          <button key={item.title} className="w-full bg-white rounded-lg border border-border p-4 flex items-center gap-4 hover:bg-muted/20 transition-colors text-left">
            <div className="w-9 h-9 rounded-lg bg-[#EFF5FA] flex items-center justify-center shrink-0">
              <item.icon size={16} className="text-[#0B3D63]" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground">{item.title}</p>
              <p className="text-xs text-muted-foreground">{item.desc}</p>
            </div>
            <ChevronRight size={15} className="text-muted-foreground shrink-0" />
          </button>
        ))}
      </div>
    </div>
  );
}

// ── Animation detail extra tabs ───────────────────────────────────────────
function ConfigurationTab({ anim }: { anim: Animation }) {
  const fields = [
    { section: "Informations générales", items: [
      { label: "Nom de l'animation", value: anim.name },
      { label: "Modèle", value: anim.model },
      { label: "Commune", value: anim.commune },
      { label: "Organisateur", value: "Office de tourisme de Valmont" },
      { label: "Période", value: anim.period },
      { label: "Description", value: "Participez au Passeport commerçant et gagnez des coffrets Localeo en visitant les commerçants de Valmont !" },
    ]},
    { section: "Commerçants participants", items: [
      { label: "Maison Lenoir", value: "Boutique cadeaux · 12 rue du Centre" },
      { label: "Atelier des Saveurs", value: "Épicerie fine · 4 place du Marché" },
      { label: "Librairie du Centre", value: "Librairie · 8 avenue Foch" },
      { label: "Le Comptoir Local", value: "Épicerie bio · 2 rue Victor Hugo" },
    ]},
    { section: "Règles du passeport", items: [
      { label: "Seuil de validation", value: "4 validations minimum" },
      { label: "Validations uniques", value: "Oui — 1 validation par commerçant" },
      { label: "Date de clôture", value: "31 août 2026 à 23h59" },
      { label: "Population éligible", value: "Participants ayant atteint 4 validations" },
    ]},
    { section: "Coffrets à gagner", items: [
      { label: "Coffret Découverte Valmont", value: "Actif · expire le 31/12/2026" },
      { label: "Coffret Gourmand Valmont", value: "Actif · expire le 31/12/2026" },
      { label: "Coffret Bien-être Valmont", value: "Actif · expire le 31/12/2026" },
    ]},
  ];

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">Configuration en lecture seule · Modifiable uniquement en statut Brouillon ou Configuration</p>
        <button className="flex items-center gap-1.5 px-3 py-1.5 border border-border rounded-lg text-xs text-muted-foreground hover:text-foreground hover:bg-muted/30 transition-colors">
          <Edit3 size={12} /> Modifier
        </button>
      </div>
      {fields.map(section => (
        <div key={section.section} className="bg-white rounded-lg border border-border overflow-hidden">
          <div className="px-4 py-3 border-b border-border bg-muted/20">
            <p className="text-xs font-semibold text-foreground uppercase tracking-wide">{section.section}</p>
          </div>
          <div className="divide-y divide-border">
            {section.items.map(item => (
              <div key={item.label} className="px-4 py-3 flex items-start gap-4">
                <span className="text-xs text-muted-foreground w-48 shrink-0 pt-0.5">{item.label}</span>
                <span className="text-sm text-foreground">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function ValidationsAnimTab({ anim }: { anim: Animation }) {
  const rows = [
    { date: "02/07/2026 14h23", merchant: "Maison Lenoir",       ref: "PART-0247", etape: "4/4", ok: true },
    { date: "02/07/2026 13h51", merchant: "Atelier des Saveurs", ref: "PART-0246", etape: "3/4", ok: true },
    { date: "02/07/2026 12h08", merchant: "Le Comptoir Local",   ref: "PART-0245", etape: "4/4", ok: true },
    { date: "01/07/2026 17h34", merchant: "Librairie du Centre", ref: "PART-0244", etape: "2/4", ok: false },
    { date: "01/07/2026 16h12", merchant: "Maison Lenoir",       ref: "PART-0243", etape: "4/4", ok: true },
    { date: "01/07/2026 14h05", merchant: "Atelier des Saveurs", ref: "PART-0242", etape: "3/4", ok: true },
    { date: "01/07/2026 11h38", merchant: "Le Comptoir Local",   ref: "PART-0241", etape: "2/4", ok: true },
    { date: "30/06/2026 16h55", merchant: "Librairie du Centre", ref: "PART-0240", etape: "1/4", ok: true },
  ];

  return (
    <div className="p-6 space-y-3">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 flex-1 max-w-xs bg-white rounded-lg border border-border px-3 py-2">
          <Search size={13} className="text-muted-foreground" />
          <input className="text-sm bg-transparent outline-none flex-1 placeholder:text-muted-foreground" placeholder="Filtrer..." />
        </div>
        {["Commerçant", "Résultat"].map(f => (
          <button key={f} className="flex items-center gap-1 text-xs border border-border bg-white rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground hover:bg-muted/30 transition-colors">
            <ChevronDown size={12} /> {f}
          </button>
        ))}
        <span className="ml-auto text-xs text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>
          {anim.validations} validations total
        </span>
      </div>
      <div className="bg-white rounded-lg border border-border overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/20">
              {["Date", "Commerçant", "Participant", "Étape", "Résultat"].map(h => (
                <th key={h} className="text-left px-4 py-2.5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {rows.map((r, i) => (
              <tr key={i} className="hover:bg-muted/20 transition-colors">
                <td className="px-4 py-2.5 text-[11px] text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{r.date}</td>
                <td className="px-4 py-2.5 text-sm">{r.merchant}</td>
                <td className="px-4 py-2.5 text-xs text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{r.ref}</td>
                <td className="px-4 py-2.5 text-xs font-medium text-muted-foreground">{r.etape}</td>
                <td className="px-4 py-2.5">
                  {r.ok
                    ? <span className="text-[11px] bg-green-50 text-green-700 px-2 py-0.5 rounded font-medium">Validé</span>
                    : <span className="text-[11px] bg-red-50 text-red-700 px-2 py-0.5 rounded font-medium">Anomalie</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function GainsAnimTab({ anim }: { anim: Animation }) {
  const gains = anim.status === "tirage_a_lancer"
    ? []
    : [
        { ref: "PART-0247", coffret: "Coffret Découverte Valmont", envoi: "28/05/2026", statut: "envoye", consomme: 2, total: 5, expiration: "28/11/2026" },
        { ref: "PART-0189", coffret: "Coffret Gourmand Valmont",   envoi: "28/05/2026", statut: "envoye", consomme: 1, total: 4, expiration: "28/11/2026" },
        { ref: "PART-0102", coffret: "Coffret Bien-être Valmont",  envoi: "29/05/2026", statut: "envoye", consomme: 0, total: 3, expiration: "29/11/2026" },
      ];

  return (
    <div className="p-6 space-y-4">
      {anim.status === "tirage_a_lancer" && (
        <AlertBanner type="info" message="Le tirage n'a pas encore été lancé. Les gains seront affichés ici après le tirage." />
      )}
      {gains.length > 0 && (
        <>
          <div className="grid grid-cols-3 gap-3">
            <KPICard label="Coffrets envoyés" value={String(gains.length)} icon={Gift} color="blue" />
            <KPICard label="En cours de consommation" value="2" icon={Activity} color="green" />
            <KPICard label="Non consommés" value="1" icon={AlertCircle} color="amber" />
          </div>
          <AlertBanner type="warning" message="1 coffret non consommé (PART-0102). Expiration le 29/11/2026 — pensez à relancer le gagnant." />
          <div className="bg-white rounded-lg border border-border overflow-hidden">
            <div className="px-4 py-3 border-b border-border">
              <p className="text-sm font-semibold text-foreground">Suivi des gains</p>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/20">
                  {["Gagnant", "Coffret", "Date envoi", "Expiration", "Consommation", "Statut"].map(h => (
                    <th key={h} className="text-left px-4 py-2 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {gains.map((g, i) => {
                  const pct = Math.round((g.consomme / g.total) * 100);
                  return (
                    <tr key={i} className="hover:bg-muted/20 transition-colors">
                      <td className="px-4 py-3 text-xs text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{g.ref}</td>
                      <td className="px-4 py-3 text-sm">{g.coffret}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{g.envoi}</td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{g.expiration}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 w-20 bg-muted rounded-full overflow-hidden">
                            <div className="h-full bg-[#0B3D63] rounded-full" style={{ width: `${pct}%` }} />
                          </div>
                          <span className="text-xs text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>
                            {g.consomme}/{g.total}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        {g.consomme === 0
                          ? <span className="text-[11px] bg-amber-50 text-amber-700 px-2 py-0.5 rounded font-medium">Non consommé</span>
                          : g.consomme < g.total
                          ? <span className="text-[11px] bg-[#EFF5FA] text-[#0B3D63] px-2 py-0.5 rounded font-medium">En cours</span>
                          : <span className="text-[11px] bg-green-50 text-green-700 px-2 py-0.5 rounded font-medium">Consommé</span>
                        }
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

function AuditTab({ anim }: { anim: Animation }) {
  const events = [
    { date: "02/07/2026 15h42", actor: "Claire Martin", action: "Tirage au sort lancé", type: "tirage", detail: "3 gagnants désignés, coffrets créés automatiquement" },
    { date: "31/05/2026 23h59", actor: "Système",       action: "Animation clôturée automatiquement", type: "system", detail: "Date de fin atteinte — population éligible figée à 112 participants" },
    { date: "15/03/2026 10h14", actor: "Claire Martin", action: "Animation publiée", type: "publish", detail: "QR d'inscription activé — URL : localeo.fr/valmont/ete2026" },
    { date: "12/03/2026 14h30", actor: "Claire Martin", action: "Flyer généré", type: "flyer", detail: "Flyer PDF v1 généré et téléchargé" },
    { date: "10/03/2026 09h22", actor: "Claire Martin", action: "Configuration complétée", type: "config", detail: "4 commerçants, 3 coffrets, seuil 4 validations" },
    { date: "08/03/2026 11h05", actor: "Claire Martin", action: "Animation créée", type: "create", detail: `Modèle : ${anim.model} — Commune : ${anim.commune}` },
  ];

  const typeColor: Record<string, string> = {
    tirage:  "bg-[#F28A2E]",
    system:  "bg-gray-400",
    publish: "bg-green-500",
    flyer:   "bg-purple-500",
    config:  "bg-[#0B3D63]",
    create:  "bg-[#0B3D63]",
  };

  return (
    <div className="p-6">
      <div className="bg-white rounded-lg border border-border p-5">
        <p className="text-sm font-semibold text-foreground mb-5">Journal d'audit</p>
        <div className="space-y-0">
          {events.map((e, i) => (
            <div key={i} className="flex gap-4">
              <div className="flex flex-col items-center">
                <div className={`w-2.5 h-2.5 rounded-full shrink-0 mt-1 ${typeColor[e.type]}`} />
                {i < events.length - 1 && <div className="w-px flex-1 min-h-[32px] bg-border mt-1" />}
              </div>
              <div className="pb-5 flex-1">
                <div className="flex items-baseline gap-3 flex-wrap">
                  <span className="text-sm font-medium text-foreground">{e.action}</span>
                  <span className="text-xs text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{e.date}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{e.detail}</p>
                <p className="text-[11px] text-muted-foreground/60 mt-0.5">par {e.actor}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Global views ──────────────────────────────────────────────────────────
function CoffretsView() {
  const coffrets = [
    { id: 1, ref: "COFF-0045", coffret: "Coffret Découverte Valmont", gagnant: "PART-0247", animation: "Passeport gourmand",  statut: "partiel",  activation: "28/05/2026", expiration: "28/11/2026", consomme: 2, total: 5, alerte: null },
    { id: 2, ref: "COFF-0044", coffret: "Coffret Gourmand Valmont",   gagnant: "PART-0189", animation: "Passeport gourmand",  statut: "faible",   activation: "28/05/2026", expiration: "28/11/2026", consomme: 1, total: 4, alerte: "faible_consommation" },
    { id: 3, ref: "COFF-0043", coffret: "Coffret Bien-être Valmont",  gagnant: "PART-0102", animation: "Passeport gourmand",  statut: "nul",      activation: "29/05/2026", expiration: "29/11/2026", consomme: 0, total: 3, alerte: "non_consomme" },
    { id: 4, ref: "COFF-0031", coffret: "Coffret Découverte Valmont", gagnant: "PART-0156", animation: "Noël 2025",          statut: "expire",   activation: "15/01/2026", expiration: "15/03/2026", consomme: 3, total: 5, alerte: "expire" },
    { id: 5, ref: "COFF-0030", coffret: "Coffret Gourmand Valmont",   gagnant: "PART-0089", animation: "Noël 2025",          statut: "complet",  activation: "14/01/2026", expiration: "14/03/2026", consomme: 4, total: 4, alerte: null },
    { id: 6, ref: "COFF-0029", coffret: "Coffret Bien-être Valmont",  gagnant: "PART-0072", animation: "Noël 2025",          statut: "complet",  activation: "14/01/2026", expiration: "14/03/2026", consomme: 3, total: 3, alerte: null },
  ];

  const statutBadge = (s: string) => {
    const m: Record<string, { label: string; cls: string }> = {
      complet: { label: "Consommé",    cls: "bg-green-50 text-green-700" },
      partiel: { label: "En cours",    cls: "bg-[#EFF5FA] text-[#0B3D63]" },
      faible:  { label: "Peu consommé",cls: "bg-amber-50 text-amber-700" },
      nul:     { label: "Non consommé",cls: "bg-[#FFF1E4] text-[#DF7720]" },
      expire:  { label: "Expiré",      cls: "bg-red-50 text-red-700" },
    };
    const c = m[s] ?? m.nul;
    return <span className={`text-[11px] px-2 py-0.5 rounded font-medium ${c.cls}`}>{c.label}</span>;
  };

  return (
    <div className="p-6 space-y-4">
      <div>
        <h1 className="text-base font-semibold text-foreground">Coffrets à gagner</h1>
        <p className="text-xs text-muted-foreground mt-0.5">{coffrets.length} coffrets envoyés · Ville de Valmont</p>
      </div>

      <AlertBanner type="warning" message="2 coffrets non ou peu consommés risquent d'expirer sans être utilisés. Pensez à relancer les gagnants." />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KPICard label="Coffrets envoyés"    value="45" icon={Gift}         color="blue" />
        <KPICard label="Consommés (total)"   value="17" icon={CheckCircle2} color="green" sub="38 % du total" />
        <KPICard label="Peu ou non consommés" value="8"  icon={AlertCircle} color="amber" />
        <KPICard label="Expirés"             value="3"  icon={Clock}        color="purple" />
      </div>

      <div className="bg-white rounded-lg border border-border overflow-hidden">
        <div className="px-4 py-2.5 border-b border-border flex items-center gap-3">
          <Search size={13} className="text-muted-foreground shrink-0" />
          <input className="text-sm bg-transparent outline-none flex-1 placeholder:text-muted-foreground" placeholder="Rechercher un coffret ou un gagnant..." />
          {["Animation", "Statut"].map(f => (
            <button key={f} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-muted/40 transition-colors">
              <ChevronDown size={12} /> {f}
            </button>
          ))}
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/20">
              {["Réf.", "Coffret", "Gagnant", "Animation", "Statut", "Activation", "Expiration", "Consommation", ""].map(h => (
                <th key={h} className="text-left px-4 py-2 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {coffrets.map(c => {
              const pct = Math.round((c.consomme / c.total) * 100);
              return (
                <tr key={c.id} className="hover:bg-muted/20 transition-colors">
                  <td className="px-4 py-3 text-[11px] text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{c.ref}</td>
                  <td className="px-4 py-3 text-sm font-medium">{c.coffret}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{c.gagnant}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{c.animation}</td>
                  <td className="px-4 py-3">{statutBadge(c.statut)}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{c.activation}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{c.expiration}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 w-16 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-[#0B3D63] rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                      <span className="text-[11px] text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{c.consomme}/{c.total}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    {c.alerte && (
                      <AlertTriangle size={13} className="text-amber-500" />
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ParticipantsGlobalView() {
  const rows = [
    { ref: "PART-0247", animation: "Passeport Été 2026",   date: "02/07/2026", val: 4, termine: true,  qualifie: true,  coffret: "Découverte Valmont" },
    { ref: "PART-0246", animation: "Passeport Été 2026",   date: "02/07/2026", val: 3, termine: false, qualifie: false, coffret: null },
    { ref: "PART-0245", animation: "Passeport Été 2026",   date: "01/07/2026", val: 4, termine: true,  qualifie: true,  coffret: null },
    { ref: "PART-0244", animation: "Passeport Été 2026",   date: "01/07/2026", val: 2, termine: false, qualifie: false, coffret: null },
    { ref: "PART-0243", animation: "Passeport Été 2026",   date: "30/06/2026", val: 4, termine: true,  qualifie: true,  coffret: null },
    { ref: "PART-0189", animation: "Passeport gourmand",   date: "12/03/2026", val: 4, termine: true,  qualifie: true,  coffret: "Gourmand Valmont" },
    { ref: "PART-0156", animation: "Passeport gourmand",   date: "05/03/2026", val: 4, termine: true,  qualifie: true,  coffret: null },
    { ref: "PART-0102", animation: "Animation Noël 2025",  date: "05/12/2025", val: 4, termine: true,  qualifie: true,  coffret: "Bien-être Valmont" },
  ];

  return (
    <div className="p-6 space-y-4">
      <div>
        <h1 className="text-base font-semibold text-foreground">Participants</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Toutes animations confondues · Ville de Valmont</p>
      </div>

      <AlertBanner type="info" message="Les données nominatives (nom, prénom, email, téléphone) sont masquées. Seules les références anonymisées sont visibles ici." />

      <div className="grid grid-cols-4 gap-3">
        <KPICard label="Participants total"  value="812" icon={Users}        color="blue" />
        <KPICard label="Ayant terminé"       value="486" icon={CheckCircle2} color="green" sub="60 % complétion" />
        <KPICard label="Qualifiés"           value="214" icon={UserCheck}    color="purple" />
        <KPICard label="Ayant gagné"         value="45"  icon={Trophy}       color="amber" />
      </div>

      <div className="bg-white rounded-lg border border-border overflow-hidden">
        <div className="px-4 py-2.5 border-b border-border flex items-center gap-3">
          <Search size={13} className="text-muted-foreground shrink-0" />
          <input className="text-sm bg-transparent outline-none flex-1 placeholder:text-muted-foreground" placeholder="Filtrer par référence ou animation..." />
          {["Animation", "Qualifiés", "Terminés"].map(f => (
            <button key={f} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-muted/40 transition-colors">
              <ChevronDown size={12} /> {f}
            </button>
          ))}
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/20">
              {["Référence", "Animation", "Inscription", "Validations", "Terminé", "Qualifié", "Coffret gagné"].map(h => (
                <th key={h} className={`px-4 py-2 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide ${h === "Validations" ? "text-right" : "text-left"}`}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {rows.map((r, i) => (
              <tr key={i} className="hover:bg-muted/20 transition-colors">
                <td className="px-4 py-2.5 text-xs text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{r.ref}</td>
                <td className="px-4 py-2.5 text-xs">{r.animation}</td>
                <td className="px-4 py-2.5 text-xs text-muted-foreground">{r.date}</td>
                <td className="px-4 py-2.5 text-right font-semibold text-sm" style={{ fontFamily: "'Geist Mono', monospace" }}>{r.val}</td>
                <td className="px-4 py-2.5">
                  {r.termine ? <Check size={13} className="text-green-600" /> : <span className="text-xs text-muted-foreground">—</span>}
                </td>
                <td className="px-4 py-2.5">
                  {r.qualifie
                    ? <span className="text-[11px] bg-purple-50 text-purple-700 px-2 py-0.5 rounded font-medium">Qualifié</span>
                    : <span className="text-xs text-muted-foreground">—</span>}
                </td>
                <td className="px-4 py-2.5 text-xs text-muted-foreground">
                  {r.coffret ? <span className="flex items-center gap-1"><Gift size={11} className="text-amber-500" />{r.coffret}</span> : "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ValidationsGlobalView() {
  const rows = [
    { date: "02/07/2026 14h23", animation: "Passeport Été 2026",  merchant: "Maison Lenoir",       ref: "PART-0247", ok: true },
    { date: "02/07/2026 13h51", animation: "Passeport Été 2026",  merchant: "Atelier des Saveurs", ref: "PART-0246", ok: true },
    { date: "02/07/2026 12h08", animation: "Passeport Été 2026",  merchant: "Le Comptoir Local",   ref: "PART-0245", ok: true },
    { date: "01/07/2026 17h34", animation: "Passeport Été 2026",  merchant: "Librairie du Centre", ref: "PART-0244", ok: false },
    { date: "01/07/2026 16h12", animation: "Passeport Été 2026",  merchant: "Maison Lenoir",       ref: "PART-0243", ok: true },
    { date: "18/05/2026 10h44", animation: "Passeport gourmand",  merchant: "Atelier des Saveurs", ref: "PART-0189", ok: true },
    { date: "18/05/2026 09h30", animation: "Passeport gourmand",  merchant: "Maison Lenoir",       ref: "PART-0156", ok: true },
    { date: "12/12/2025 15h20", animation: "Noël 2025",           merchant: "Le Comptoir Local",   ref: "PART-0102", ok: false },
  ];

  return (
    <div className="p-6 space-y-4">
      <div>
        <h1 className="text-base font-semibold text-foreground">Validations</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Toutes animations confondues · Ville de Valmont</p>
      </div>

      <div className="grid grid-cols-4 gap-3">
        <KPICard label="Validations totales"  value="1 934" icon={CheckSquare} color="blue" />
        <KPICard label="Validées"             value="1 891" icon={CheckCircle2} color="green" />
        <KPICard label="Anomalies"            value="43"    icon={AlertCircle}  color="amber" />
        <KPICard label="Commerçants actifs"   value="4"     icon={Store}        color="teal" />
      </div>

      <div className="bg-white rounded-lg border border-border overflow-hidden">
        <div className="px-4 py-2.5 border-b border-border flex items-center gap-3">
          <Search size={13} className="text-muted-foreground shrink-0" />
          <input className="text-sm bg-transparent outline-none flex-1 placeholder:text-muted-foreground" placeholder="Filtrer les validations..." />
          {["Animation", "Commerçant", "Résultat"].map(f => (
            <button key={f} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-2 py-1 rounded hover:bg-muted/40 transition-colors">
              <ChevronDown size={12} /> {f}
            </button>
          ))}
          <button className="ml-auto flex items-center gap-1.5 px-3 py-1.5 border border-border bg-white rounded-lg text-xs hover:bg-muted/30 transition-colors">
            <Download size={12} /> Exporter
          </button>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/20">
              {["Date", "Animation", "Commerçant", "Participant", "Résultat"].map(h => (
                <th key={h} className="text-left px-4 py-2 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {rows.map((r, i) => (
              <tr key={i} className="hover:bg-muted/20 transition-colors">
                <td className="px-4 py-2.5 text-[11px] text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{r.date}</td>
                <td className="px-4 py-2.5 text-xs">{r.animation}</td>
                <td className="px-4 py-2.5 text-sm">{r.merchant}</td>
                <td className="px-4 py-2.5 text-xs text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{r.ref}</td>
                <td className="px-4 py-2.5">
                  {r.ok
                    ? <span className="text-[11px] bg-green-50 text-green-700 px-2 py-0.5 rounded font-medium">Validé</span>
                    : <span className="text-[11px] bg-red-50 text-red-700 px-2 py-0.5 rounded font-medium">Anomalie</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function TiragesGlobalView({ onOpen }: { onOpen: (id: number) => void }) {
  const tirages = [
    { animId: 2, name: "Passeport gourmand",         period: "Mars – mai 2026",    status: "tirage_a_lancer", eligibles: 112, coffrets: 3, tirageDone: false, gagnants: 0 },
    { animId: 3, name: "Animation Noël 2025",         period: "Déc. 2025",          status: "archivee",        eligibles: 58,  coffrets: 2, tirageDone: true,  gagnants: 2 },
    { animId: 1, name: "Passeport commerçant Été 2026", period: "Juin – août 2026", status: "en_cours",        eligibles: 0,   coffrets: 3, tirageDone: false, gagnants: 0 },
  ];

  return (
    <div className="p-6 space-y-4">
      <div>
        <h1 className="text-base font-semibold text-foreground">Tirages et gains</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Vue globale des tirages par animation</p>
      </div>

      <AlertBanner
        type="warning"
        message="Passeport gourmand — Tirage à lancer. 112 participants éligibles attendent."
        action="Lancer →"
        onAction={() => onOpen(2)}
      />

      <div className="grid grid-cols-3 gap-3">
        <KPICard label="Tirages effectués"  value="2"  icon={Shuffle}       color="blue" />
        <KPICard label="Gagnants désignés"  value="45" icon={Trophy}        color="amber" />
        <KPICard label="Coffrets envoyés"   value="45" icon={Gift}          color="green" />
      </div>

      <div className="space-y-3">
        {tirages.map(t => (
          <div key={t.animId} className="bg-white rounded-xl border border-border p-5">
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-sm font-semibold text-foreground">{t.name}</h3>
                  <StatusBadge status={t.status} />
                </div>
                <p className="text-xs text-muted-foreground">{t.period}</p>
              </div>
              <button
                onClick={() => onOpen(t.animId)}
                className="text-xs text-[#0B3D63] hover:underline font-medium flex items-center gap-1"
              >
                Voir la fiche <ChevronRight size={12} />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-4 mb-4">
              <div>
                <p className="text-[11px] text-muted-foreground">Participants éligibles</p>
                <p className="text-lg font-semibold text-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>
                  {t.eligibles > 0 ? t.eligibles : "—"}
                </p>
              </div>
              <div>
                <p className="text-[11px] text-muted-foreground">Coffrets disponibles</p>
                <p className="text-lg font-semibold text-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{t.coffrets}</p>
              </div>
              <div>
                <p className="text-[11px] text-muted-foreground">Gagnants désignés</p>
                <p className="text-lg font-semibold text-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>
                  {t.tirageDone ? t.gagnants : "—"}
                </p>
              </div>
            </div>

            {t.status === "tirage_a_lancer" && (
              <button
                onClick={() => onOpen(t.animId)}
                className="flex items-center gap-2 px-4 py-2 bg-[#F28A2E] text-white rounded-lg text-sm font-medium hover:bg-[#DF7720] transition-colors"
              >
                <Shuffle size={14} /> Lancer le tirage au sort
              </button>
            )}
            {t.tirageDone && (
              <div className="flex items-center gap-2 text-xs text-green-700 bg-green-50 px-3 py-2 rounded-lg">
                <CheckCircle2 size={13} /> Tirage effectué — {t.gagnants} gagnants désignés
              </div>
            )}
            {t.status === "en_cours" && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/40 px-3 py-2 rounded-lg">
                <Clock size={13} /> Animation en cours — tirage disponible après clôture
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function FlyersGlobalView({ onOpen }: { onOpen: (id: number) => void }) {
  const flyers = [
    { animId: 1, name: "Passeport commerçant – Été 2026", commune: "Valmont", genere: "14/06/2026", statut: "ok",       url: "localeo.fr/valmont/ete2026" },
    { animId: 2, name: "Passeport gourmand",              commune: "Valmont", genere: "28/02/2026", statut: "regenerer", url: "localeo.fr/valmont/gourmand" },
    { animId: 3, name: "Animation Noël 2025",             commune: "Valmont", genere: "30/11/2025", statut: "ok",       url: "localeo.fr/valmont/noel2025" },
  ];

  return (
    <div className="p-6 space-y-4">
      <div>
        <h1 className="text-base font-semibold text-foreground">Flyers</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Supports de communication par animation</p>
      </div>

      {flyers.some(f => f.statut === "regenerer") && (
        <AlertBanner type="warning" message="1 flyer est à régénérer suite à des modifications de l'animation." />
      )}

      <div className="space-y-3">
        {flyers.map(f => (
          <div key={f.animId} className="bg-white rounded-xl border border-border p-5 flex items-center gap-6">
            {/* Preview thumbnail */}
            <div className="w-16 h-20 rounded-lg bg-[#0B3D63] flex flex-col items-center justify-center shrink-0 overflow-hidden">
              <div className="w-8 h-8 bg-white/20 rounded mb-1 flex items-center justify-center">
                <QrCode size={16} className="text-white/80" />
              </div>
              <div className="w-10 h-1 bg-white/40 rounded mb-0.5" />
              <div className="w-8 h-1 bg-white/30 rounded" />
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="text-sm font-semibold text-foreground">{f.name}</h3>
                {f.statut === "ok"
                  ? <span className="flex items-center gap-1 text-[11px] bg-green-50 text-green-700 border border-green-200 px-1.5 py-0.5 rounded font-medium"><CheckCircle2 size={10} />À jour</span>
                  : <span className="flex items-center gap-1 text-[11px] bg-amber-50 text-amber-700 border border-amber-200 px-1.5 py-0.5 rounded font-medium"><AlertTriangle size={10} />À régénérer</span>
                }
              </div>
              <p className="text-xs text-muted-foreground">{f.commune} · Généré le {f.genere}</p>
              <p className="text-xs text-[#0B3D63] mt-0.5">{f.url}</p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {f.statut === "regenerer" && (
                <button className="flex items-center gap-1.5 px-3 py-1.5 border border-amber-300 text-amber-700 rounded-lg text-xs font-medium hover:bg-amber-50 transition-colors">
                  <RefreshCw size={12} /> Régénérer
                </button>
              )}
              <button className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0B3D63] text-white rounded-lg text-xs font-medium hover:bg-[#0D456D] transition-colors">
                <Download size={12} /> Télécharger
              </button>
              <button onClick={() => onOpen(f.animId)} className="p-1.5 border border-border rounded-lg hover:bg-muted/30 transition-colors">
                <ChevronRight size={14} className="text-muted-foreground" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function BilansGlobalView({ onOpen }: { onOpen: (id: number) => void }) {
  const rows = [
    { animId: 1, name: "Passeport Été 2026",  period: "Juin – août 2026", status: "en_cours",       inscrits: 247, termines: 148, qualifies: 89,  validations: 634, coffrets: 0,  completion: 60 },
    { animId: 2, name: "Passeport gourmand",   period: "Mars – mai 2026",  status: "tirage_a_lancer",inscrits: 312, termines: 198, qualifies: 112, validations: 801, coffrets: 3,  completion: 63 },
    { animId: 3, name: "Noël 2025",            period: "Déc. 2025",        status: "archivee",       inscrits: 253, termines: 140, qualifies: 58,  validations: 499, coffrets: 2,  completion: 55 },
  ];

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-base font-semibold text-foreground">Bilans</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Résultats consolidés · Ville de Valmont</p>
        </div>
        <button className="flex items-center gap-1.5 px-3 py-1.5 border border-border bg-white rounded-lg text-xs font-medium hover:bg-muted/30 transition-colors">
          <Download size={13} /> Exporter tout (CSV)
        </button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KPICard label="Total inscrits"    value="812"   icon={Users}        color="blue" />
        <KPICard label="Total validations" value="1 934" icon={CheckSquare}  color="teal" />
        <KPICard label="Total qualifiés"   value="214"   icon={Trophy}       color="purple" />
        <KPICard label="Coffrets envoyés"  value="45"    icon={Gift}         color="amber" />
      </div>

      <div className="bg-white rounded-lg border border-border overflow-hidden">
        <div className="px-4 py-3 border-b border-border flex items-center justify-between">
          <p className="text-sm font-semibold text-foreground">Comparaison des animations</p>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/20">
              {["Animation", "Période", "Statut", "Inscrits", "Terminés", "Complétion", "Qualifiés", "Validations", "Coffrets", ""].map(h => (
                <th key={h} className={`px-4 py-2 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide ${
                  ["Inscrits","Terminés","Qualifiés","Validations","Coffrets"].includes(h) ? "text-right" : "text-left"
                }`}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {rows.map(r => (
              <tr key={r.animId} className="hover:bg-muted/20 transition-colors cursor-pointer" onClick={() => onOpen(r.animId)}>
                <td className="px-4 py-3 font-medium text-foreground">{r.name}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground whitespace-nowrap">{r.period}</td>
                <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                <td className="px-4 py-3 text-right" style={{ fontFamily: "'Geist Mono', monospace" }}>{r.inscrits}</td>
                <td className="px-4 py-3 text-right" style={{ fontFamily: "'Geist Mono', monospace" }}>{r.termines}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-2">
                    <div className="h-1.5 w-14 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-[#0B3D63] rounded-full" style={{ width: `${r.completion}%` }} />
                    </div>
                    <span className="text-xs text-muted-foreground" style={{ fontFamily: "'Geist Mono', monospace" }}>{r.completion}%</span>
                  </div>
                </td>
                <td className="px-4 py-3 text-right" style={{ fontFamily: "'Geist Mono', monospace" }}>{r.qualifies}</td>
                <td className="px-4 py-3 text-right" style={{ fontFamily: "'Geist Mono', monospace" }}>{r.validations}</td>
                <td className="px-4 py-3 text-right" style={{ fontFamily: "'Geist Mono', monospace" }}>{r.coffrets}</td>
                <td className="px-4 py-3">
                  <ChevronRight size={14} className="text-muted-foreground" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Create Wizard ─────────────────────────────────────────────────────────
function CreateWizardView({ onBack }: { onBack: () => void }) {
  const [step, setStep] = useState(1);
  const [data, setData] = useState({
    model: "passeport", name: "", desc: "", organisateur: "Office de tourisme de Valmont",
    dateDebut: "", dateFin: "", merchants: [] as string[], seuil: "4",
    coffrets: [] as string[],
  });

  const STEPS = [
    { n: 1, label: "Modèle" },
    { n: 2, label: "Commune" },
    { n: 3, label: "Informations" },
    { n: 4, label: "Commerçants" },
    { n: 5, label: "Règles" },
    { n: 6, label: "Coffrets" },
    { n: 7, label: "Flyer" },
    { n: 8, label: "Récapitulatif" },
  ];

  const MERCHANTS = ["Maison Lenoir", "Atelier des Saveurs", "Librairie du Centre", "Le Comptoir Local"];
  const COFFRETS = ["Coffret Découverte Valmont", "Coffret Gourmand Valmont", "Coffret Bien-être Valmont"];

  const toggleArr = (arr: string[], val: string) =>
    arr.includes(val) ? arr.filter(x => x !== val) : [...arr, val];

  const canNext = () => {
    if (step === 3) return data.name.trim() !== "" && data.dateDebut !== "" && data.dateFin !== "";
    if (step === 4) return data.merchants.length >= 2;
    if (step === 6) return data.coffrets.length >= 1;
    return true;
  };

  const isComplete = step === 8;

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* Header */}
      <div className="bg-white border-b border-border px-6 py-4 shrink-0">
        <button onClick={onBack} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground mb-3 transition-colors">
          <ChevronLeft size={13} /> Animations
        </button>
        <h1 className="text-base font-semibold text-foreground">Nouvelle animation</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Commune active : Ville de Valmont</p>
      </div>

      {/* Stepper */}
      <div className="bg-white border-b border-border px-6 py-3 shrink-0">
        <div className="flex items-center gap-0">
          {STEPS.map((s, i) => (
            <div key={s.n} className="flex items-center">
              <button
                onClick={() => s.n < step && setStep(s.n)}
                className={`flex items-center gap-1.5 px-2 py-1 rounded text-xs font-medium transition-colors ${
                  s.n === step ? "text-[#0B3D63]" :
                  s.n < step  ? "text-green-600 cursor-pointer hover:bg-muted/30" :
                                 "text-muted-foreground"
                }`}
              >
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                  s.n < step  ? "bg-green-100 text-green-700" :
                  s.n === step ? "bg-[#0B3D63] text-white" :
                                 "bg-muted text-muted-foreground"
                }`}>
                  {s.n < step ? <Check size={10} /> : s.n}
                </span>
                <span className="hidden lg:block">{s.label}</span>
              </button>
              {i < STEPS.length - 1 && (
                <div className={`h-px w-4 mx-0.5 ${s.n < step ? "bg-green-300" : "bg-border"}`} />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-2xl mx-auto p-6 space-y-4">

          {/* Step 1 - Modèle */}
          {step === 1 && (
            <div className="space-y-3">
              <h2 className="text-sm font-semibold">Choisissez un modèle d'animation</h2>
              <div
                onClick={() => setData(d => ({ ...d, model: "passeport" }))}
                className={`bg-white rounded-xl border-2 p-4 cursor-pointer transition-all ${data.model === "passeport" ? "border-[#0B3D63]" : "border-border hover:border-muted-foreground/30"}`}
              >
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#EFF5FA] flex items-center justify-center shrink-0">
                    <Ticket size={17} className="text-[#0B3D63]" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-semibold">Passeport commerçant</h3>
                      <span className="text-[10px] bg-green-50 text-green-700 px-1.5 py-0.5 rounded font-semibold">Disponible</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">Collectez des validations chez les commerçants et gagnez des coffrets Localeo.</p>
                  </div>
                  <div className={`w-4 h-4 rounded-full border-2 shrink-0 mt-0.5 flex items-center justify-center ${data.model === "passeport" ? "border-[#0B3D63] bg-[#0B3D63]" : "border-border"}`}>
                    {data.model === "passeport" && <Check size={10} className="text-white" />}
                  </div>
                </div>
              </div>
              {["Rallye vitrines", "Chasse au trésor", "Quiz commerçants"].map(m => (
                <div key={m} className="bg-white rounded-xl border border-border p-4 opacity-50 cursor-not-allowed">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-muted flex items-center justify-center shrink-0">
                      <Ticket size={17} className="text-muted-foreground" />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold">{m}</h3>
                      <span className="text-[10px] bg-muted text-muted-foreground px-1.5 py-0.5 rounded font-medium">Bientôt disponible</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Step 2 - Commune */}
          {step === 2 && (
            <div className="space-y-3">
              <h2 className="text-sm font-semibold">Commune active</h2>
              <div className="bg-white rounded-xl border-2 border-[#0B3D63] p-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#EFF5FA] flex items-center justify-center shrink-0">
                    <MapPin size={17} className="text-[#0B3D63]" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Ville de Valmont</p>
                    <p className="text-xs text-muted-foreground">Abonnement actif · Partenaire : OT de Valmont</p>
                  </div>
                  <Check size={16} className="text-[#0B3D63] ml-auto" />
                </div>
              </div>
              <AlertBanner type="info" message="L'animation sera rattachée à la commune active sélectionnée en haut de l'écran. Les animations multi-communes ne sont pas disponibles dans cette formule." />
            </div>
          )}

          {/* Step 3 - Informations */}
          {step === 3 && (
            <div className="space-y-4">
              <h2 className="text-sm font-semibold">Informations publiques</h2>
              <div className="bg-white rounded-xl border border-border p-4 space-y-4">
                <div>
                  <label className="text-xs font-semibold text-foreground block mb-1">Nom de l'animation <span className="text-red-500">*</span></label>
                  <input
                    value={data.name}
                    onChange={e => setData(d => ({ ...d, name: e.target.value }))}
                    placeholder="Ex : Passeport commerçant – Été 2026"
                    className="w-full text-sm border border-border rounded-lg px-3 py-2 outline-none focus:border-[#0B3D63] transition-colors"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-foreground block mb-1">Description publique</label>
                  <textarea
                    value={data.desc}
                    onChange={e => setData(d => ({ ...d, desc: e.target.value }))}
                    placeholder="Décrivez l'animation pour les participants..."
                    rows={3}
                    className="w-full text-sm border border-border rounded-lg px-3 py-2 outline-none focus:border-[#0B3D63] transition-colors resize-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-foreground block mb-1">Organisateur</label>
                  <input
                    value={data.organisateur}
                    onChange={e => setData(d => ({ ...d, organisateur: e.target.value }))}
                    className="w-full text-sm border border-border rounded-lg px-3 py-2 outline-none focus:border-[#0B3D63] transition-colors"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-foreground block mb-1">Date de début <span className="text-red-500">*</span></label>
                    <input
                      type="date"
                      value={data.dateDebut}
                      onChange={e => setData(d => ({ ...d, dateDebut: e.target.value }))}
                      className="w-full text-sm border border-border rounded-lg px-3 py-2 outline-none focus:border-[#0B3D63] transition-colors"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-foreground block mb-1">Date de fin <span className="text-red-500">*</span></label>
                    <input
                      type="date"
                      value={data.dateFin}
                      onChange={e => setData(d => ({ ...d, dateFin: e.target.value }))}
                      className="w-full text-sm border border-border rounded-lg px-3 py-2 outline-none focus:border-[#0B3D63] transition-colors"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 4 - Commerçants */}
          {step === 4 && (
            <div className="space-y-3">
              <h2 className="text-sm font-semibold">Commerçants participants</h2>
              <p className="text-xs text-muted-foreground">Sélectionnez au minimum 2 commerçants. Les participants devront valider un QR chez chacun d'eux.</p>
              {data.merchants.length < 2 && (
                <AlertBanner type="warning" message="Sélectionnez au moins 2 commerçants pour pouvoir continuer." />
              )}
              <div className="space-y-2">
                {MERCHANTS.map(m => {
                  const selected = data.merchants.includes(m);
                  return (
                    <button
                      key={m}
                      onClick={() => setData(d => ({ ...d, merchants: toggleArr(d.merchants, m) }))}
                      className={`w-full flex items-center gap-3 p-3 rounded-xl border-2 text-left transition-all ${selected ? "border-[#0B3D63] bg-[#EFF5FA]/40" : "border-border bg-white hover:border-muted-foreground/30"}`}
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${selected ? "bg-[#0B3D63]" : "bg-muted"}`}>
                        <Store size={14} className={selected ? "text-white" : "text-muted-foreground"} />
                      </div>
                      <span className="text-sm font-medium text-foreground flex-1">{m}</span>
                      <div className={`w-4 h-4 rounded-full border-2 shrink-0 flex items-center justify-center ${selected ? "border-[#0B3D63] bg-[#0B3D63]" : "border-border"}`}>
                        {selected && <Check size={10} className="text-white" />}
                      </div>
                    </button>
                  );
                })}
              </div>
              <p className="text-xs text-muted-foreground">{data.merchants.length} commerçant(s) sélectionné(s)</p>
            </div>
          )}

          {/* Step 5 - Règles */}
          {step === 5 && (
            <div className="space-y-4">
              <h2 className="text-sm font-semibold">Règles du passeport</h2>
              <div className="bg-white rounded-xl border border-border p-4 space-y-4">
                <div>
                  <label className="text-xs font-semibold text-foreground block mb-1">Seuil de validation (nombre de commerçants à visiter)</label>
                  <select
                    value={data.seuil}
                    onChange={e => setData(d => ({ ...d, seuil: e.target.value }))}
                    className="w-full text-sm border border-border rounded-lg px-3 py-2 outline-none focus:border-[#0B3D63] transition-colors bg-white"
                  >
                    {["2","3","4"].map(v => <option key={v} value={v}>{v} validations minimum</option>)}
                  </select>
                </div>
                <div className="flex items-start gap-3 p-3 bg-muted/30 rounded-lg">
                  <Info size={14} className="text-muted-foreground shrink-0 mt-0.5" />
                  <p className="text-xs text-muted-foreground">
                    Un participant ayant atteint le seuil de <strong>{data.seuil} validations</strong> parmi les {data.merchants.length} commerçants sélectionnés sera éligible au tirage au sort.
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-5 bg-[#0B3D63] rounded-full flex items-center justify-end px-0.5">
                    <div className="w-4 h-4 bg-white rounded-full" />
                  </div>
                  <label className="text-sm text-foreground">1 validation par commerçant (recommandé)</label>
                </div>
              </div>
            </div>
          )}

          {/* Step 6 - Coffrets */}
          {step === 6 && (
            <div className="space-y-3">
              <h2 className="text-sm font-semibold">Coffrets à gagner</h2>
              <p className="text-xs text-muted-foreground">Uniquement les coffrets Localeo actifs de la commune de Valmont sont éligibles.</p>
              {data.coffrets.length === 0 && (
                <AlertBanner type="warning" message="Sélectionnez au moins 1 coffret pour pouvoir publier l'animation." />
              )}
              <div className="space-y-2">
                {COFFRETS.map(c => {
                  const selected = data.coffrets.includes(c);
                  return (
                    <button
                      key={c}
                      onClick={() => setData(d => ({ ...d, coffrets: toggleArr(d.coffrets, c) }))}
                      className={`w-full flex items-center gap-3 p-3 rounded-xl border-2 text-left transition-all ${selected ? "border-[#0B3D63] bg-[#EFF5FA]/40" : "border-border bg-white hover:border-muted-foreground/30"}`}
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${selected ? "bg-amber-500" : "bg-muted"}`}>
                        <Gift size={14} className={selected ? "text-white" : "text-muted-foreground"} />
                      </div>
                      <div className="flex-1 text-left">
                        <p className="text-sm font-medium text-foreground">{c}</p>
                        <p className="text-[11px] text-green-600">Actif · Valmont · Expire 31/12/2026</p>
                      </div>
                      <div className={`w-4 h-4 rounded-full border-2 shrink-0 flex items-center justify-center ${selected ? "border-[#0B3D63] bg-[#0B3D63]" : "border-border"}`}>
                        {selected && <Check size={10} className="text-white" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Step 7 - Flyer */}
          {step === 7 && (
            <div className="space-y-4">
              <h2 className="text-sm font-semibold">Aperçu du flyer</h2>
              <div className="bg-white border-2 border-border rounded-xl overflow-hidden shadow-sm">
                <div className="bg-[#0B3D63] px-6 py-5 text-white text-center">
                  <p className="text-[10px] font-semibold uppercase tracking-widest opacity-60 mb-1">Ville de Valmont</p>
                  <h2 className="text-lg font-bold leading-snug mb-1">{data.name || "Nom de l'animation"}</h2>
                  <p className="text-sm opacity-75">{data.dateDebut && data.dateFin ? `${data.dateDebut} – ${data.dateFin}` : "Dates à définir"}</p>
                </div>
                <div className="p-5 flex gap-5 items-start">
                  <div className="flex-1">
                    <p className="text-sm text-muted-foreground mb-3">{data.desc || "Description de l'animation..."}</p>
                    <p className="text-xs text-muted-foreground"><strong className="text-foreground">Organisateur :</strong> {data.organisateur}</p>
                  </div>
                  <div className="w-20 h-20 bg-muted rounded-lg flex flex-col items-center justify-center border border-border shrink-0">
                    <QrCode size={28} className="text-muted-foreground" />
                    <p className="text-[9px] text-muted-foreground mt-1 text-center">QR inscription</p>
                  </div>
                </div>
              </div>
              <AlertBanner type="info" message="Le QR d'inscription sera généré automatiquement à la publication. Le flyer PDF sera disponible en téléchargement après publication." />
            </div>
          )}

          {/* Step 8 - Récapitulatif */}
          {step === 8 && (
            <div className="space-y-4">
              <h2 className="text-sm font-semibold">Récapitulatif avant publication</h2>
              {(!canNext() || data.coffrets.length === 0) && (
                <AlertBanner type="error" message="Configuration incomplète. Vérifiez les étapes précédentes avant de publier." />
              )}
              <div className="space-y-2">
                {[
                  { label: "Modèle", value: "Passeport commerçant", ok: true },
                  { label: "Commune", value: "Ville de Valmont", ok: true },
                  { label: "Nom", value: data.name || "—", ok: data.name.trim() !== "" },
                  { label: "Période", value: data.dateDebut && data.dateFin ? `${data.dateDebut} → ${data.dateFin}` : "Non définie", ok: data.dateDebut !== "" && data.dateFin !== "" },
                  { label: "Commerçants", value: data.merchants.length > 0 ? data.merchants.join(", ") : "Aucun", ok: data.merchants.length >= 2 },
                  { label: "Seuil", value: `${data.seuil} validations minimum`, ok: true },
                  { label: "Coffrets", value: data.coffrets.length > 0 ? data.coffrets.join(", ") : "Aucun", ok: data.coffrets.length >= 1 },
                ].map(item => (
                  <div key={item.label} className="flex items-start gap-3 py-2 border-b border-border last:border-0">
                    {item.ok
                      ? <Check size={14} className="text-green-600 shrink-0 mt-0.5" />
                      : <AlertCircle size={14} className="text-red-500 shrink-0 mt-0.5" />}
                    <span className="text-xs text-muted-foreground w-24 shrink-0">{item.label}</span>
                    <span className="text-sm text-foreground flex-1">{item.value}</span>
                  </div>
                ))}
              </div>
              <AlertBanner type="info" message="La publication rend l'animation visible et active le QR d'inscription. Cette action demande une confirmation." />
            </div>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between pt-2">
            <button
              onClick={() => step > 1 ? setStep(s => s - 1) : onBack()}
              className="flex items-center gap-1.5 px-4 py-2 border border-border rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-muted/30 transition-colors"
            >
              <ChevronLeft size={14} /> {step > 1 ? "Précédent" : "Annuler"}
            </button>

            {!isComplete ? (
              <button
                onClick={() => canNext() && setStep(s => s + 1)}
                disabled={!canNext()}
                className={`flex items-center gap-1.5 px-5 py-2 rounded-lg text-sm font-medium transition-colors ${
                  canNext()
                    ? "bg-[#0B3D63] text-white hover:bg-[#0D456D]"
                    : "bg-muted text-muted-foreground cursor-not-allowed"
                }`}
              >
                Continuer <ChevronRight size={14} />
              </button>
            ) : (
              <button
                onClick={() => onBack()}
                className="flex items-center gap-1.5 px-5 py-2 bg-[#F28A2E] text-white rounded-lg text-sm font-medium hover:bg-[#DF7720] transition-colors"
              >
                Publier l'animation <ArrowRight size={14} />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── App ───────────────────────────────────────────────────────────────────
export default function App() {
  const [view, setView] = useState("dashboard");
  const [animId, setAnimId] = useState<number | null>(null);

  const handleNav = (v: string) => { setView(v); setAnimId(null); };
  const handleOpen = (id: number) => { setAnimId(id); setView("animation-detail"); };
  const handleCreateWizard = () => setView("create-wizard");

  const renderMain = () => {
    if (view === "animation-detail" && animId !== null) {
      return <AnimationDetailView id={animId} onBack={() => handleNav("animations")} />;
    }
    if (view === "create-wizard") {
      return <CreateWizardView onBack={() => handleNav("animations")} />;
    }
    switch (view) {
      case "dashboard":    return <DashboardView onOpen={handleOpen} />;
      case "animations":   return <AnimationsView onOpen={handleOpen} onCreate={handleCreateWizard} />;
      case "models":       return <ModelsView onNav={handleNav} onCreate={handleCreateWizard} />;
      case "abonnement":   return <AbonnementView />;
      case "support":      return <SupportView />;
      case "coffrets":     return <CoffretsView />;
      case "participants": return <ParticipantsGlobalView />;
      case "validations":  return <ValidationsGlobalView />;
      case "tirages":      return <TiragesGlobalView onOpen={handleOpen} />;
      case "flyers":       return <FlyersGlobalView onOpen={handleOpen} />;
      case "bilans":       return <BilansGlobalView onOpen={handleOpen} />;
      default:             return <DashboardView onOpen={handleOpen} />;
    }
  };

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar current={view} onNav={handleNav} />
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <TopBar onNav={handleNav} />
        <main className="flex-1 overflow-y-auto min-h-0">
          {renderMain()}
        </main>
      </div>
    </div>
  );
}
